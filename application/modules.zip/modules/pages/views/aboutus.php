<?php
$themeurl=$this->base."themes/public/";
?>
<?= Modules::run('pages/widgets/breadcrumb')?>
<?php  echo $pagedata['page_cms'];?>
      
<?= Modules::run('pages/widgets/team')?>
<?php  echo $pagedata['page_cms2'];?>
     
    


    