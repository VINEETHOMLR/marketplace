<?= Modules::run('pages/widgets/top_destinations')?>
<?= Modules::run('pages/widgets/home_cars')?>
<?= Modules::run('pages/widgets/home_tours')?>
<?= Modules::run('pages/widgets/testimonials')?>
<?= Modules::run('pages/widgets/home_hotels')?>
<?= Modules::run('pages/widgets/clients')?>

    

      