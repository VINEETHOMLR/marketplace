<div class="right-section book-form">
	<button class="hvr-bounce-to-right book-now-btn"  data-toggle="modal" data-target="#exampleModal">Book Now</button>
</div>
<div class="right-section get-quote-main">
	<h3>Got a Question?</h3>
	<p>Do not hesitate to give us a call. We are an expert team and we are happy to talk to you.</p>
	<div class="contact-numbers">
		<a href="tel:+91-9544703000"><i class="flaticon-phone-call" aria-hidden="true"></i> +91 9544 70 3000</a>
	</div>
	<div class="contact-email">
		<p><a href="mailto:info@jeevatours.in"><i class="flaticon-message" aria-hidden="true"></i> info@jeevatours.in</a></p>
	</div>
</div>