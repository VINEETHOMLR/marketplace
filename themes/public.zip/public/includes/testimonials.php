<section class="tg-main-section tg-testimonial-img tg-haslayout">
   <div class="container">
      <div class="row">
         <div class="tg-testimonials tg-haslayout">
            <div class="col-lg-7 col-md-7 col-sm-7 col-md-offset-3">
               <div id="tg-testi-slider" class="tg-testi-slider">
                  <div class="item">
                     <div class="tg-theme-heading">
                        <span>our happy customers</span>
                        <h2>Mr. David <span></span></h2>
                     </div>
                     <div class="tg-description">
                     <figure><img src="images/testimoanial-img.jpg" alt=""></figure>
                     <blockquote>
                        <q>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</q>
                     </blockquote>
                  </div>
               </div>
               <div class="item">
                  <div class="tg-theme-heading">
                     <span>our happy customers</span>
                     <h2>Mr. David <span></span></h2>
                  </div>
                  <div class="tg-description">
                  <figure><img src="images/testimoanial-img-1.jpg" alt=""></figure>
                  <blockquote>
                     <q>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</q>
                  </blockquote>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</section>