<div class="tg-haslayout">
   <div class="tg-theme-heading">
      <span>Our Top</span>
      <h2>Brands</h2>
   </div>
   <div class="clearfix"></div>
   <div class="tg-brands">
      <div id="tg-posts-slider" class="tg-posts">
         <div class="item">
            <figure>
               <a href="#"><img src="images/brands/brand-1.jpg" alt="brand name"></a>
            </figure>
         </div>
         <div class="item">
            <figure>
               <a href="#"><img src="images/brands/brand-2.jpg" alt="brand name"></a>
            </figure>
         </div>
         <div class="item">
            <figure>
               <a href="#"><img src="images/brands/brand-3.jpg" alt="brand name"></a>
            </figure>
         </div>
         <div class="item">
            <figure>
               <a href="#"><img src="images/brands/brand-4.jpg" alt="brand name"></a>
            </figure>
         </div>
         <div class="clearfix"></div>
      </div>
   </div>
</div>