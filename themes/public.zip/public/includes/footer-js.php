<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.bxslider.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/parallax.js"></script>
<script src="js/isotope.pkgd.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/classie.js"></script>
<script src="js/gnmenu.js"></script>
<script src="http://maps.google.com/maps/api/js?key=AIzaSyDlh_AGFXk44DuUVd6BDFas5XgqevprVms&amp;language=en"></script>
<script src="js/gmap3.js"></script>
<script src="js/main.js"></script>
<script>new gnMenu( document.getElementById( 'gn-menu' ) );</script>
<script>
$(document).ready(function(){
$(".phone-btn").click(function(){
$(".call").toggleClass("call-hide");
$(this).toggleClass("arrow-rotate");
});
});
</script>
<script>
   $(document).ready(function(){
   $(".slide-toggle").click(function(){
   $(".add-nav").slideToggle();
   });
   });
</script>