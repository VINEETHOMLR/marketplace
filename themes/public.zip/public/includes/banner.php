<ul id="bx-home-slider" class="home slider">
   <li class="swiper-slide">
      <figure><img src="images/home-slider2/img-01.jpg" alt="image description"></figure>
   </li>
   <li class="swiper-slide">
      <figure><img src="images/home-slider2/img-02.jpg" alt="image description"></figure>
   </li>
   <li class="swiper-slide">
      <figure><img src="images/home-slider2/img-03.jpg" alt="image description"></figure>
   </li>
</ul>